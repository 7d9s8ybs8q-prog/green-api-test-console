# GREEN-API Test Console

Static HTML page for testing GREEN-API methods.
Built as a test task for the DevOps Engineer position.

## Stack

- Vanilla HTML / CSS / JavaScript
- No build step, no dependencies
- Single file (`index.html`)

## Implemented methods

| Method             | HTTP | Description                                  |
| ------------------ | ---- | -------------------------------------------- |
| `getSettings`      | GET  | Fetch instance settings                      |
| `getStateInstance` | GET  | Get the current state of the WhatsApp link   |
| `sendMessage`      | POST | Send a text message to a chat                |
| `sendFileByUrl`    | POST | Send a file by its public URL                |

All requests are made to:

```
https://api.green-api.com/waInstance{idInstance}/{method}/{apiTokenInstance}
```

## How to use

1. Create an instance in your [GREEN-API console](https://console.green-api.com/) and link it to your WhatsApp number (QR code).
2. Open the deployed page (see link in submission email or run locally — just open `index.html` in a browser).
3. Paste your `idInstance` and `ApiTokenInstance` into the corresponding fields.
4. Click `getStateInstance` to verify the link is authorized.
5. Enter a phone number (digits only, with country code, e.g. `77001234567`) and a message, then click `sendMessage`.
6. To send a file, enter a phone number and a public file URL, then click `sendFileByUrl`.

## Run locally

No build required:

```bash
# any static server works
python3 -m http.server 8080
# or
npx serve .
```

Then open <http://localhost:8080>.

## Deployment

Deployed via GitHub Pages from the `main` branch (root).
